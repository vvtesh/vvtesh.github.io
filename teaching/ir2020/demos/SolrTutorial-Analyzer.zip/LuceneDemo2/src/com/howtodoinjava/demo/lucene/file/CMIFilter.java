package com.howtodoinjava.demo.lucene.file;

import java.io.IOException;

import javax.print.DocFlavor.INPUT_STREAM;

import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;

public class CMIFilter extends TokenFilter  {

	private CharTermAttribute charTermAttr;
	
	protected CMIFilter(TokenStream input) {
		super(input);
	    this.charTermAttr = addAttribute(CharTermAttribute.class);
	}

	@Override
	public boolean incrementToken() throws IOException {
		if (!input.incrementToken()) {
		      return false;
		    }
		int length = charTermAttr.length();
	    char[] buffer = charTermAttr.buffer();
	    char[] newBuffer = new char[length];
	    for (int i = 0; i < length; i++) {
	      newBuffer[i] = (char) (buffer[i]+1);
	    }
	    charTermAttr.setEmpty();
	    charTermAttr.copyBuffer(newBuffer, 0, newBuffer.length);
	    return true;
	}

}
