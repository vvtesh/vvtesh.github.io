package com.howtodoinjava.demo.lucene.file;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;

public class MyNonStandardAnalyzer extends Analyzer {

	@Override
	protected TokenStreamComponents createComponents(String fieldName) {
		Tokenizer source = new CMITokenizer();
	    TokenStream filter = new CMIFilter(source);
	    //filter = new CMIFilter2(filter);
	    return new TokenStreamComponents(source, filter);
	}


}
