package com.howtodoinjava.demo.lucene.file;

import java.io.IOException;

import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.util.CharTokenizer;

public class CMITokenizer extends CharTokenizer {

	@Override
	protected boolean isTokenChar(int ch) {
		return ch!='*';
	}

}
