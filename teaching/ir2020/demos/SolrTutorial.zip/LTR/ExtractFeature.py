# -*- coding: utf-8 -*-
"""
EXTRACT FEATURES FOR MODEL TRAINING
"""

import os
import pandas as pd
from sklearn.svm import LinearSVC
from sklearn.model_selection import train_test_split

os.chdir('C:/solr/Tutorial/')


### column name of feature extacted from solr
col_names=['isCatergory','views','original_score']
    
document = pd.read_csv("100Data.csv")

#result_features = pd.DataFrame(columns = col_names)


    
features = document["[features]"].str.split(pat=",")
print(features)

#results_features=pd.DataFrame([])
category_array = []
views_array=[]
score_array=[]
for feature in features:
    category_array.append(feature[0].split("=")[1])
    views_array.append(feature[1].split("=")[1])
    score_array.append(feature[2].split("=")[1])   
    #print(pd.Series(feature_array, col_names))

result=pd.DataFrame({'isCategory': category_array, 'views': views_array,'score':score_array})
# saving the feature data as training dataset
result.to_csv('FeatureData.csv')




min=0
max=16601927

delta=max-min


# reading training dataset
featureData=pd.read_csv("FeatureData.csv") 

### Min Max Normalisation
featureData['Views_Normalised']=(featureData.views - min) / delta

## extracting dependent variable as X
X = featureData[['isCategory','Views_Normalised','score']]
# setting relevant column as Y
y = featureData.Relevant


# spliting dataset into test & train
xTrain, xTest, yTrain, yTest = train_test_split(X, y, test_size = 0.3, random_state = 0)

# building SVM Linear classifier  
model = LinearSVC()
model.fit(X, y)
preds_rproba = model._predict_proba_lr(xTest)
preds=model.predict(xTest)
## insample accuracy
print(model.score(xTrain, yTrain))
## outsample accuracy
print(model.score(xTest, yTest))

## feature weights
print(model.coef_)



