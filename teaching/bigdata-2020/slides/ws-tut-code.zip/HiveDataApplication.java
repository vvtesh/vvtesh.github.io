package rest_api;

import javax.ws.rs.ApplicationPath;
import org.glassfish.jersey.server.ResourceConfig; 

@ApplicationPath("/")
public class HiveDataApplication extends ResourceConfig {               

    public HiveDataApplication() {
        packages("rest_api");
    }
}