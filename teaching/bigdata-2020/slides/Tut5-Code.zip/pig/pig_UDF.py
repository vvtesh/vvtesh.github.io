# -*- coding: utf-8 -*-


'''
# Import the plotting library
import matplotlib.pyplot as plt
 
# Import the yfinance. If you get module not found error the run !pip install yfiannce from your Jupyter notebook
import yfinance as yf  
 
# Get the data of the stock Amazon
data = yf.download('AMZN','2008-01-01','2020-01-01')
 
# Plot the close price of the Amazon
data.Close.plot()
plt.show()

data.to_csv('E:\MSc_Datascience\BigDataHadoop\Slides\stock.csv')

'''


'''
## Volume Weighted Average Price
It that gives the average price a security was traded
at throughout the day, based on both volume and price

VWAP= sum(Price * Volume)/ sum(Volume)

'''
def calVWAP(year,volume, price):
   num,denom= 0,0
   temp1, temp2 = [], []    
   
   for v in volume:
       temp1.append(v[0])
       denom += v[0]

   for p in price:
       temp2.append(p[0])
    
   for i in range(0, len(temp1)):
       num += temp1[i]*temp2[i]
	   
   val = num / denom
   return year[0][0],val



