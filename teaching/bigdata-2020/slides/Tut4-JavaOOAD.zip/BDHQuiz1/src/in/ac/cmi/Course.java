package in.ac.cmi;

import java.util.ArrayList;
import java.util.List;

public class Course {
	String id;
	String name;
	Instructor instructor;
	List<Student> students = new ArrayList<Student>();
	
	private void getDetails() {
		System.out.println(id + "," + name);
	}
	
	public void enrol(Student student) {
		students.add(student);
	}
	
	public void printEnrollment() {
		for(Student student: students) {
			System.out.println(student.name);
		}
	}
}
