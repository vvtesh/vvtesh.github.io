package in.ac.cmi;

public class Instructor implements Person {
	String empID;
	String name;
	@Override
	public void printDetails() {
		System.out.println(name);
		
	}
}
