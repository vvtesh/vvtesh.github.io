package in.ac.cmi;

public interface Person {
	void printDetails();
}
