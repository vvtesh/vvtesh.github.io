package in.ac.cmi;

public class CMI {
	public static void main(String[] args) {
		Course course = new Course();
		course.id = "BDH";
		course.name = "Big Data with Hadoop";
		
		Instructor instructor = new Instructor();
		instructor.empID = "1112";
		instructor.name = "Venkatesh";
		
		Student nilanjan = new Student();
		nilanjan.name = "Nilanjan";
		nilanjan.rollno = "MDS01010101";
		
		course.enrol(nilanjan);
		
		Student ashish = new Student();
		ashish.name = "Ashish";
		ashish.rollno = "MDS02010101";
		
		course.enrol(ashish);
		
		course.printEnrollment();
		
		ashish.printDetails();
	}
}
