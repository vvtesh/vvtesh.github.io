package in.ac.cmi;

public class Student implements Person {
	String rollno;
	String name;
	boolean yawns = false;
	@Override
	public void printDetails() {
		System.out.println(rollno);		
	}
	
	
}
